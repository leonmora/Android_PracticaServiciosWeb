/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rest;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Saul
 */
@Path("Convertidor")
public class ConvertidorResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ConvertidorResource
     */
    public ConvertidorResource() {
    }

    /**
     * Retrieves representation of an instance of rest.ConvertidorResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getText() {
        return "Servicio en Línea";
    }

    @GET
    @Path("/MXN/cantidad={monto}&tipo={divisa}")
    @Produces(MediaType.TEXT_PLAIN)
    public String convertir(@PathParam("monto")String monto,@PathParam("divisa")String divisa){
        double mont=Double.parseDouble(monto);
        int div=Integer.parseInt(divisa);
        String convertido="";
        switch(div)
        {
            case 1:
                convertido=""+(mont/18);
                break;
            case 2:
                convertido=""+(mont/10.8);
                break;
            case 3:
              convertido=""+(mont/21);
                break;
            case 4:
              convertido=""+(mont/.16);
                break;
            case 5:
              convertido=""+(mont/2.74);
                break;
        }
        return convertido;
    }
    /**
     * PUT method for updating or creating an instance of ConvertidorResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.TEXT_PLAIN)
    public void putText(String content) {
    }
}
