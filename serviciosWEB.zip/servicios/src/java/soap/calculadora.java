/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soap;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Saul
 */
@WebService(serviceName = "calculadora")
public class calculadora {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName="getResultado")
    public String getResultado(@WebParam(name="numA")String numA,@WebParam(name="numB")String numB,@WebParam(name="op")String op){
        double A=Double.parseDouble(numA);
        double B=Double.parseDouble(numB);
        int operador=Integer.parseInt(op);
        String resultado="";
        switch(operador){
            case 1:
                resultado=""+(A+B);
                break;
            case 2:
                resultado=""+(A-B);
                break;
            case 3:
                resultado=""+(A/B);
                break;
            case 4:
                resultado=""+(A*B);
                break;
        }
        return resultado;
    }
}
