/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soap;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Saul
 */
@WebService(serviceName = "login")
public class login {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName = "iniciarSesion")
    public String iniciarSesion(@WebParam(name="nombre")String nombre,@WebParam(name="clave")String clave){
        String paso="";
        if(nombre.equalsIgnoreCase("LeonMora"))
            if(clave.equalsIgnoreCase("LeonMora"))
                paso="Sesión Iniciada";
            else
                paso="Clave incorrecta";
        else
          paso="Usuario incorrecto"; 
        return paso;
    }
}
